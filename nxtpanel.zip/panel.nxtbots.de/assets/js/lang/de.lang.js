var lang = {
    "PASSWORD_CHANGED": "Passwort geändert",
    "PASSWORD_CHANGED_MESSAGE": "Dein Passwort wurde geändert",
    "PASSWORD_CHANGED_EMESSAGE": "Die angegebenen Passwörter stimmen nicht überein",

    "ADDRESS_CHANGED": "Adresse geändert",
    "ADDRESS_CHANGED_MESSAGE": "Deine Adresse wurde geändert",

    "DELETE_USER": "Benutzer Löschen",
    "DELETE_USER_SURE": "Du löscht damit dich und all deine MusikBot´s. Bist du dir wirklich sicher?",

    "BOT_CREATED": "Musikbot Erstellt",
    "BOT_CREATED_MESSAGE": "Dein Bot wurde erstellt und Du kannst ihn nun benutzen",
    "BOT_DELETE": "Bot Löschen",
    "BOT_DELETE_CONFIRM": "Du löscht Damit deinen Bot und hast keine Chance mehr diesen zurück zu bekommen",
    "BOT_DELETE_WORD": "Löschen",

    "BOT_DELETED": "Bot gelöscht",
    "BOT_DELETED_SUCCESS": "Dein Bot wurde gelöscht",

    "STATION_UPDATED": "Stationen aktualisiert",
    "STATION_UPDATED_MESSAGE": "Deine Quickplay Stationen wurden aktualisiert",

    "SETTINGS_CHANGED": "Einstellungen geändert",
    "SETTINGS_CHANGED_MESSAGE": "Die Einstellungen deines Bot wurden geändert",

    "STATION_CHANGED": "Sender geändert",
    "STATION_CHANGED_MESSAGE": "Des Bot Spielt nun: <strong>%station%</strong>",

    "TICKET_TO_MUCH": "Zu viele Tickets",
    "TICKET_TO_MUCH_MESSAGE": "Du hast derzeit leider zu viele offene Tickets",

    "ERROR": "Verarbeitungsfehler",
    "ERROR_MESSAGE": "Leider gab es einen Fehler beim ausführen der Anfrage",
    "VOLUME": "Lautstärke",
};